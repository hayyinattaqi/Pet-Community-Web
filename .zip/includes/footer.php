<footer class="footer bg-dark text-white p-4">
    <div class="row justify-content-center text-center text-lg-start">
        <div class="col-lg-4 footer__section">
            <h3>About Us.</h3>
            <p>Didedikasikan untuk menciptakan dunia di mana setiap hewan peliharaan memiliki rumah yang penuh kasih dan setiap komunitas peduli terhadap hewannya.❤️</p>
        </div>
        <div class="col-lg-4 footer__section">
            <h3>Contact Us.</h3>
            <p><i class="fas fa-envelope"></i> info@companyname.com</p>
            <p><i class="fas fa-phone"></i> (+62) 8431 3849 23</p>
            <p><i class="fas fa-map-marker-alt"></i> Jl. Godean Km. 5, Ambarketawang, Gamping, Sleman</p>
        </div>
        <div class="col-lg-4 footer__section">
            <h3>Quick Links.</h3>
            <ul class="footer__nav-list p-0" style="list-style: none;">
                <li><a href="about.php" class="footer__links" style="text-decoration: none;">About</a></li>
                <li><a href="program.php"class="footer__links " style="text-decoration: none;">Our Programs</a></li>
                <li><a href="contact.php"class="footer__links" style="text-decoration: none;">Contact Us</a></li>
                <li><a href="donations.php"class="footer__links" style="text-decoration: none;">Donate</a></li>
            </ul>
        </div>
    </div>
</footer>