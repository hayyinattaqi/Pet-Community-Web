<?php
session_start();

// Hapus semua session

session_unset(); // Kosongkan semua data
session_destroy();

echo "Session telah dibersihkan. <a href='login.php'>Kembali ke Login</a>";

// Redirect ke halaman login
//header("Location: login.php");
exit();
?>